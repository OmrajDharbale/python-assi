# Student Record and Academic Management System

A simple Python console application for managing student records and academic marks.

## Features
- Add student details (Roll Number, Name, PRN, Class, Division)
- Search by Roll Number or PRN
- View all student records
- Calculate total marks, average marks, and grade
- Save records in `students.json` so they remain available between runs
- Validate marks between 0 and 100

## Requirements
- Python 3.8 or newer
- No third-party packages required

## Run
Open a terminal in this folder and run:

```bash
python student_management.py
```

On Windows, if needed:

```bash
py student_management.py
```

## Grade rules
- Average >= 80: A
- Average >= 70: B
- Average >= 60: C
- Average < 60: F

## Note
`students.json` is created automatically after the first student is added. Use sample data only if publishing this project publicly.
