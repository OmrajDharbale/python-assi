import json
import os

FILE_NAME = "students.json"


def load_students():
    if os.path.exists(FILE_NAME):
        try:
            with open(FILE_NAME, "r", encoding="utf-8") as file:
                return json.load(file)
        except (json.JSONDecodeError, OSError):
            return []
    return []


def save_students(students):
    with open(FILE_NAME, "w", encoding="utf-8") as file:
        json.dump(students, file, indent=4)


def calculate_result(marks):
    total = sum(marks)
    average = total / len(marks)

    if average >= 80:
        grade = "A"
    elif average >= 70:
        grade = "B"
    elif average >= 60:
        grade = "C"
    else:
        grade = "F"

    return total, average, grade


def display_student(student):
    total, average, grade = calculate_result(student["marks"])

    print("\\n========== STUDENT DETAILS ==========")
    print("Roll Number :", student["roll"])
    print("Name        :", student["name"])
    print("PRN         :", student["prn"])
    print("Class       :", student["class"])
    print("Division    :", student["division"])

    print("\\nSubject-wise Marks:")
    for i, mark in enumerate(student["marks"], start=1):
        print(f"Subject {i}: {mark}")

    print("-------------------------------------")
    print("Total Marks :", total)
    print("Average     :", round(average, 2))
    print("Grade       :", grade)
    print("=====================================")


def add_student(students):
    print("\\n--- ADD STUDENT ---")

    roll = input("Enter Roll Number: ").strip()
    prn = input("Enter PRN: ").strip()

    if not roll or not prn:
        print("Roll Number and PRN cannot be empty.")
        return

    for student in students:
        if student["roll"] == roll or student["prn"] == prn:
            print("Roll Number or PRN already exists!")
            return

    name = input("Enter Name: ").strip()
    student_class = input("Enter Class: ").strip()
    division = input("Enter Division: ").strip()

    if not name or not student_class or not division:
        print("Student details cannot be empty.")
        return

    try:
        number = int(input("Enter number of subjects: "))
        if number <= 0:
            print("Number of subjects must be positive.")
            return

        marks = []
        for i in range(number):
            while True:
                try:
                    mark = float(input(f"Enter marks for Subject {i + 1}: "))
                    if 0 <= mark <= 100:
                        marks.append(mark)
                        break
                    print("Marks must be between 0 and 100.")
                except ValueError:
                    print("Please enter a valid number.")

    except ValueError:
        print("Please enter a valid number of subjects.")
        return

    student = {
        "roll": roll,
        "name": name,
        "prn": prn,
        "class": student_class,
        "division": division,
        "marks": marks
    }

    students.append(student)
    save_students(students)
    print("Student Added Successfully!")


def search_student(students):
    print("\\n--- SEARCH STUDENT ---")
    key = input("Enter Roll Number or PRN: ").strip()

    for student in students:
        if student["roll"] == key or student["prn"] == key:
            display_student(student)
            return

    print("Student Not Found!")


def view_students(students):
    print("\\n--- ALL STUDENT RECORDS ---")
    if not students:
        print("No student records available.")
        return

    for student in students:
        display_student(student)


def main():
    students = load_students()

    while True:
        print("\\n======================================")
        print(" STUDENT RECORD AND ACADEMIC SYSTEM")
        print("======================================")
        print("1. Add Student")
        print("2. Search Student")
        print("3. View All Students")
        print("4. Exit")
        print("======================================")

        choice = input("Enter your choice (1-4): ").strip()

        if choice == "1":
            add_student(students)
        elif choice == "2":
            search_student(students)
        elif choice == "3":
            view_students(students)
        elif choice == "4":
            print("Thank you for using the system!")
            break
        else:
            print("Invalid choice. Please select 1, 2, 3 or 4.")


if __name__ == "__main__":
    main()
